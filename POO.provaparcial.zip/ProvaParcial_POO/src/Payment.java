
public interface Payment {
	public double calculatePayment(); //--> corresponde a calcularPagamento
}
